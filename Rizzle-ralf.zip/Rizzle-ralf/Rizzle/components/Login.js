import React, { Component } from 'react'
import { StyleSheet, Text, View, Image,
    TouchableWithoutFeedback, StatusBar,
    TextInput, SafeAreaView, Keyboard, TouchableOpacity,    
    KeyboardAvoidingView } from 'react-native'

export default class Login extends Component {
    render() {
        return (<view style ={styles.container}> </view>)
    }
}


const styles = StyleSheet.create({
    container: {
        flex:1,
        backgroundColor: 'rgb(32, 53, 70)',
        flexDirection: 'column',
    }
})
