import { AppRegistry } from 'react-native';
import Splash from './components/Splash';
AppRegistry.registerComponent('Rizzle', () => Splash)